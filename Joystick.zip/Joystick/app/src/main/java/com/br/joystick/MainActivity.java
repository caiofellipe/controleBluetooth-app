package com.br.joystick;

import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    ImageView image_joystick, image_border;
    TextView textView1, textView2, textView3, textView4, textView5;
    RelativeLayout layout_joystick;
    JoystickClass js;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        textView1 = findViewById(R.id.textView1);
        textView2 = findViewById(R.id.textView2);
        textView3 = findViewById(R.id.textView3);
        textView4 = findViewById(R.id.textView4);
        textView5 = findViewById(R.id.textView5);

        layout_joystick = (RelativeLayout)findViewById(R.id.layout_joystick);

        js = new JoystickClass(getApplicationContext(), layout_joystick, R.drawable.image_button);
        js.setStickSize(150, 150);
        js.setLayoutSize(500, 500);
        js.setLayoutAlpha(150);
        js.setStickAlpha(100);
        js.setOffset(90);
        js.setMinimumDistance(50);

        layout_joystick.setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View arg0, MotionEvent arg1) {
                //js.drawStick(arg1);
                MainActivity.this.js.drawStick(arg1);
                if(arg1.getAction() == MotionEvent.ACTION_DOWN || arg1.getAction() == MotionEvent.ACTION_MOVE) {
                    MainActivity.this.textView1.setText("X : " + js.getX());
                    MainActivity.this.textView2.setText("Y : " + js.getY());
                    MainActivity.this.textView3.setText("Angle : " + js.getAngle());
                    MainActivity.this.textView4.setText("Distance : " + js.getDistance());

                    int direction = js.get8Direction();
                    if(direction == JoystickClass.STICK_UP) {
                        textView5.setText("Direction : Up");
                    } else if(direction == JoystickClass.STICK_UPRIGHT) {
                        textView5.setText("Direction : Up Right");
                    } else if(direction == JoystickClass.STICK_RIGHT) {
                        textView5.setText("Direction : Right");
                    } else if(direction == JoystickClass.STICK_DOWNRIGHT) {
                        textView5.setText("Direction : Down Right");
                    } else if(direction == JoystickClass.STICK_DOWN) {
                        textView5.setText("Direction : Down");
                    } else if(direction == JoystickClass.STICK_DOWNLEFT) {
                        textView5.setText("Direction : Down Left");
                    } else if(direction == JoystickClass.STICK_LEFT) {
                        textView5.setText("Direction : Left");
                    } else if(direction == JoystickClass.STICK_UPLEFT) {
                        textView5.setText("Direction : Up Left");
                    } else if(direction == JoystickClass.STICK_NONE) {
                        textView5.setText("Direction : Center");
                    }
                } else if(arg1.getAction() == MotionEvent.ACTION_UP) {
                    textView1.setText("X :");
                    textView2.setText("Y :");
                    textView3.setText("Angle :");
                    textView4.setText("Distance :");
                    textView5.setText("Direction :");
                }
                return true;
            }
        });
    }
}
